# Topsis-Yashika-102317089
This is a Python package for calculating TOPSIS score and rank.
Usage: `topsis <InputDataFile> <Weights> <Impacts> <ResultFileName>`